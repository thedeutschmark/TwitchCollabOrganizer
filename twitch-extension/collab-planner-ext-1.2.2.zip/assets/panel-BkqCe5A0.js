import { r as reactExports, j as jsxRuntimeExports, c as clientExports, D as DEFAULT_CONFIG, a as awaitAuthorized, b as awaitConfiguration, p as parseConfig, f as fetchPanel } from "./configSchema-DsEGYoBR.js";
function resolveViewerTimeZone() {
  return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
}
function resolveViewerLocale(twitchLocale) {
  if (typeof navigator !== "undefined" && navigator.language) return navigator.language;
  return "en-US";
}
function pickTextColor(hex) {
  const m = /^#([0-9a-fA-F]{6})$/.exec(hex);
  if (!m) return "#FFFFFF";
  const n = parseInt(m[1], 16);
  const r = n >> 16 & 255;
  const g = n >> 8 & 255;
  const b = n & 255;
  const channel = (c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  const L = 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
  return L > 0.179 ? "#000000" : "#FFFFFF";
}
const DAY_NAMES_FULL = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const DAY_NAMES_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
function formatHour12(hour) {
  const h = (hour % 24 + 24) % 24;
  const h12 = h % 12 || 12;
  return `${h12} ${h >= 12 ? "PM" : "AM"}`;
}
function formatDayList(topDays) {
  if (topDays.length === 0) return "";
  const full = topDays.map((d) => DAY_NAMES_FULL[DAY_NAMES_SHORT.indexOf(d)]).filter(Boolean);
  if (full.length === 1) return `${full[0]}s`;
  if (full.length === 2) return `${full[0]}s & ${full[1]}s`;
  return `${full.slice(0, -1).map((d) => `${d}s`).join(", ")} & ${full[full.length - 1]}s`;
}
function tzDisplayNames(tz) {
  try {
    const now = /* @__PURE__ */ new Date();
    const shortFmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "short" });
    const longFmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "long" });
    const short = shortFmt.formatToParts(now).find((p) => p.type === "timeZoneName")?.value ?? tz;
    const long = longFmt.formatToParts(now).find((p) => p.type === "timeZoneName")?.value ?? tz;
    return { short, long };
  } catch {
    return { short: tz, long: tz };
  }
}
const TODAY_GRACE_HOURS = 3;
function nextLikelyLiveDate(topDays, medianHour) {
  if (topDays.length === 0) return null;
  const activeDows = topDays.map((d) => DAY_NAMES_SHORT.indexOf(d)).filter((i) => i !== -1);
  if (activeDows.length === 0) return null;
  const now = /* @__PURE__ */ new Date();
  const graceMs = TODAY_GRACE_HOURS * 36e5;
  for (let i = 0; i < 14; i++) {
    const candidate = new Date(now);
    candidate.setDate(candidate.getDate() + i);
    candidate.setHours(medianHour, 0, 0, 0);
    if (candidate.getTime() <= now.getTime() - graceMs) continue;
    if (activeDows.includes(candidate.getDay())) return candidate;
  }
  return null;
}
function formatCountdown(target, nowMs) {
  if (!target) return "";
  const diffMs = target.getTime() - nowMs;
  if (diffMs <= 0) return "any min";
  const totalMin = Math.floor(diffMs / 6e4);
  const days = Math.floor(totalMin / (24 * 60));
  const hours = Math.floor(totalMin % (24 * 60) / 60);
  const mins = totalMin % 60;
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}
function nextLikelyRelative(topDays, medianHour) {
  if (topDays.length === 0) return null;
  const activeDows = topDays.map((d) => DAY_NAMES_SHORT.indexOf(d)).filter((i) => i !== -1);
  if (activeDows.length === 0) return null;
  const now = /* @__PURE__ */ new Date();
  const todayDow = now.getDay();
  const currentHour = now.getHours();
  for (let i = 0; i < 7; i++) {
    const checkDow = (todayDow + i) % 7;
    if (!activeDows.includes(checkDow)) continue;
    if (i === 0 && currentHour >= medianHour + TODAY_GRACE_HOURS) continue;
    const dayLabel = DAY_NAMES_SHORT[checkDow];
    const fullDay = DAY_NAMES_FULL[checkDow];
    let relative;
    if (i === 0) {
      const hoursAway = medianHour - currentHour;
      if (hoursAway <= 0) relative = "any minute";
      else if (hoursAway <= 2) relative = "soon";
      else if (hoursAway <= 6) relative = `in ${hoursAway}h`;
      else relative = "tonight";
    } else if (i === 1) relative = "tomorrow";
    else relative = `in ${i} days`;
    return { dayLabel, fullDay, relative };
  }
  return null;
}
function buildVariant(args) {
  const { topDays, medianHour, avgDurationHours, next, countdown, tzShort, tzLong } = args;
  const start = formatHour12(medianHour);
  const end = formatHour12(medianHour + Math.max(1, Math.round(avgDurationHours)));
  const tz = /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "prose-tz", title: tzLong, children: tzShort });
  if (!next) {
    return {
      eyebrow: "Next likely live",
      hero: "—",
      heroTone: "dim",
      support: "No regular streaming pattern yet."
    };
  }
  if (next.relative === "any minute") {
    return {
      eyebrow: "Usually live",
      hero: "Right now",
      support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
          next.fullDay,
          "s"
        ] }),
        " · ",
        /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
          start,
          " to ",
          end
        ] }),
        " ",
        tz
      ] })
    };
  }
  if (next.relative === "soon" || next.relative === "tonight" || next.relative.startsWith("in ") && !next.relative.includes("day")) {
    return {
      eyebrow: "Tonight's stream in",
      hero: countdown || next.relative,
      support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Usually ",
        /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
          next.fullDay,
          "s"
        ] }),
        " around ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: start }),
        " ",
        tz,
        "."
      ] })
    };
  }
  if (next.relative === "tomorrow") {
    return {
      eyebrow: "Next stream",
      hero: "Tomorrow",
      support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: next.fullDay }),
        " around ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: start }),
        " ",
        tz,
        "."
      ] }),
      secondary: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Usually ",
        formatDayList(topDays),
        "."
      ] })
    };
  }
  return {
    eyebrow: "Next likely live",
    hero: next.fullDay,
    support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: next.relative }),
      " · around ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: start }),
      " ",
      tz,
      "."
    ] }),
    secondary: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Usually ",
      formatDayList(topDays),
      "."
    ] })
  };
}
function ScheduleSummary({ summary }) {
  const { topDays, medianHour, avgDurationHours, tz, isEstimate, hasPostedSchedule } = summary;
  const tzNames = tzDisplayNames(tz);
  const next = nextLikelyRelative(topDays, medianHour);
  const nextDate = nextLikelyLiveDate(topDays, medianHour);
  const [nowMs, setNowMs] = reactExports.useState(Date.now());
  reactExports.useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 6e4);
    return () => clearInterval(id);
  }, []);
  const countdown = formatCountdown(nextDate, nowMs);
  const v = buildVariant({
    topDays,
    medianHour,
    avgDurationHours,
    next,
    countdown,
    tzShort: tzNames.short,
    tzLong: tzNames.long
  });
  const eyebrowText = isEstimate ? `${v.eyebrow} (est.)` : v.eyebrow;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule-eyebrow", children: [
      eyebrowText,
      hasPostedSchedule && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "schedule-posted", title: "Has posted Twitch schedule", children: "●" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `schedule-hero schedule-hero-${v.heroTone ?? "accent"}`, children: v.hero }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-support", children: v.support }),
    v.secondary && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-secondary", children: v.secondary })
  ] });
}
function formatClock(ms) {
  return new Date(ms).toLocaleTimeString(void 0, {
    hour: "numeric",
    minute: "2-digit"
  });
}
function PoweredByFooter({ campaign, generatedAt }) {
  const href = `https://collab.deutschmark.online/?utm_source=twitch_ext&utm_medium=panel&utm_campaign=${campaign}`;
  const [nowMs, setNowMs] = reactExports.useState(Date.now());
  reactExports.useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 6e4);
    return () => clearInterval(id);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "powered-by", children: [
    generatedAt && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "powered-by-tick", title: `Data refreshed ${formatClock(new Date(generatedAt).getTime())}`, children: [
      "as of ",
      formatClock(nowMs)
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href, target: "_blank", rel: "noopener noreferrer", children: [
      "Powered by Collab Planner ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "↗" })
    ] })
  ] });
}
const MIN_SPAN_HOURS = 10;
const PAD_BEFORE = 2;
const PAD_AFTER = 1;
function computeAxisRange(perDay) {
  const high = perDay.filter((d) => d.confidence === "high");
  if (high.length === 0) {
    return { startHour: 12, endHour: 24 };
  }
  const earliestStart = Math.min(...high.map((d) => d.startHour));
  const latestEnd = Math.max(...high.map((d) => d.startHour + d.durationHours));
  let startHour = earliestStart - PAD_BEFORE;
  const endHour = latestEnd + PAD_AFTER;
  if (endHour <= 24 && endHour - startHour < MIN_SPAN_HOURS) {
    startHour = Math.max(0, endHour - MIN_SPAN_HOURS);
  }
  return { startHour, endHour };
}
const DAY_LETTERS$1 = ["S", "M", "T", "W", "T", "F", "S"];
function fmtHour(h) {
  const hr = (h % 24 + 24) % 24;
  const h12 = hr % 12 || 12;
  return `${h12}${hr >= 12 ? "p" : "a"}`;
}
function nowHourInTz(tz) {
  const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false });
  const parts = fmt.formatToParts(/* @__PURE__ */ new Date());
  const h = parseInt(parts.find((p) => p.type === "hour")?.value ?? "0", 10);
  const m = parseInt(parts.find((p) => p.type === "minute")?.value ?? "0", 10);
  return (h === 24 ? 0 : h) + m / 60;
}
function nowDowInTz(tz) {
  const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" });
  const w = fmt.formatToParts(/* @__PURE__ */ new Date()).find((p) => p.type === "weekday")?.value ?? "Sun";
  return { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[w] ?? 0;
}
function Heatmap({ perDay, tz }) {
  const [, setTick] = reactExports.useState(0);
  reactExports.useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 6e4);
    return () => clearInterval(id);
  }, []);
  if (!perDay || perDay.length === 0) return null;
  const { startHour, endHour } = computeAxisRange(perDay);
  const spanH = endHour - startHour;
  const todayDow = nowDowInTz(tz);
  const nowH = nowHourInTz(tz);
  const nowInRange = nowH >= startHour && nowH < endHour;
  const nowPct = nowInRange ? (nowH - startHour) / spanH * 100 : -1;
  const ticks = [];
  for (let h = Math.ceil(startHour / 2) * 2; h < endHour; h += 2) {
    ticks.push({ hour: h, pct: (h - startHour) / spanH * 100 });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-eyebrow", children: "WEEKLY SCHEDULE" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-rows", children: DAY_LETTERS$1.map((letter, dow) => {
      const entry = perDay.find((d) => d.dow === dow);
      const isToday = dow === todayDow;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `weekcal-row ${isToday ? "weekcal-row-today" : ""}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `weekcal-day ${isToday ? "weekcal-day-today" : entry ? "weekcal-day-active" : "weekcal-day-empty"}`, children: letter }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-strip", children: [
          ticks.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "weekcal-gridline",
              style: { left: `${t.pct}%` }
            },
            t.hour
          )),
          entry && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `weekcal-pill weekcal-pill-${entry.confidence}`,
              style: {
                left: `${(entry.startHour - startHour) / spanH * 100}%`,
                width: `${entry.durationHours / spanH * 100}%`
              },
              title: `${fmtHour(entry.startHour)}–${fmtHour(entry.startHour + entry.durationHours)}${entry.confidence === "low" ? " (low confidence)" : ""}`
            }
          )
        ] })
      ] }, dow);
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-axis", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-axis-corner" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-axis-track", children: [
        ticks.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-axis-tick", style: { left: `${t.pct}%` }, children: fmtHour(t.hour) }, t.hour)),
        nowInRange && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-now-line", style: { left: `${nowPct}%` } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-now-chip", style: { left: `${nowPct}%` } })
        ] })
      ] })
    ] })
  ] });
}
function formatElapsed(startedAtMs, nowMs) {
  const diff = Math.max(0, nowMs - startedAtMs);
  const totalMin = Math.floor(diff / 6e4);
  const hours = Math.floor(totalMin / 60);
  const mins = totalMin % 60;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}
function LiveNowHero({ liveNow }) {
  const startedAtMs = new Date(liveNow.startedAt).getTime();
  const [nowMs, setNowMs] = reactExports.useState(Date.now());
  reactExports.useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 6e4);
    return () => clearInterval(id);
  }, []);
  const elapsed = formatElapsed(startedAtMs, nowMs);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule live-hero", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule-eyebrow live-eyebrow", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "live-dot", "aria-hidden": true }),
      "Live now"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-hero schedule-hero-live", children: elapsed }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-support", children: liveNow.gameName ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Streaming ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: liveNow.gameName }),
      "."
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: "Live right now." }) }),
    liveNow.title && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-secondary live-title", title: liveNow.title, children: liveNow.title })
  ] });
}
const DAY_LETTERS = ["S", "M", "T", "W", "T", "F", "S"];
function NoDataSkeleton() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-eyebrow", children: "Predictions pending" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-hero schedule-hero-dim", children: "—" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-support", children: "Not enough broadcast history yet." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-secondary", children: "Once there are a few streams, this slot turns into a live-by-day forecast." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal skeleton", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-header", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-corner" }),
        DAY_LETTERS.map((letter, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-day-label", children: letter }, i))
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-body", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-row", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-hour-label", children: "—" }),
        DAY_LETTERS.map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-cell" }, i))
      ] }) })
    ] })
  ] });
}
const WARMING_RETRY_MS = 5e3;
function Panel() {
  const [state, setState] = reactExports.useState({ kind: "loading" });
  const [config, setConfig] = reactExports.useState(DEFAULT_CONFIG);
  reactExports.useEffect(() => {
    let cancelled = false;
    let timer = null;
    const previewMode = new URLSearchParams(window.location.search).get("preview");
    if (previewMode) {
      const fmt = {
        locale: resolveViewerLocale(),
        timeZone: resolveViewerTimeZone()
      };
      if (previewMode === "warming") {
        setState({ kind: "warming", fmt });
      } else if (previewMode === "no_data") {
        setState({ kind: "no_data", fmt });
      } else {
        const mock = {
          status: "ok",
          summary: {
            topDays: ["Mon", "Wed", "Sat"],
            medianHour: 19,
            // 7 PM local
            tz: "America/New_York",
            topGame: "Fortnite",
            topGames: ["Fortnite", "Just Chatting", "League of Legends"],
            isEstimate: false,
            hasPostedSchedule: true,
            // Spread evening hours: ramps up 6-8 PM, peaks 8-10, tails to midnight.
            hourDistribution: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4, 0.9, 1, 0.9, 0.6, 0.3],
            // Mon + Wed + Sat are the regulars; everything else background noise.
            dayFrequency: [0.2, 1, 0.2, 0.9, 0.3, 0.2, 0.8],
            avgDurationHours: 5,
            perDay: [
              { dow: 1, startHour: 19, durationHours: 5, confidence: "high" },
              { dow: 3, startHour: 19, durationHours: 5, confidence: "high" },
              { dow: 6, startHour: 18, durationHours: 5, confidence: "high" }
            ],
            broadcasterAvatar: "https://static-cdn.jtvnw.net/jtv_user_pictures/54c170ef-e1d0-463d-adda-922e751ef6b8-profile_image-300x300.png",
            broadcasterName: "thedeutschmark"
          },
          lastStream: { startedAt: new Date(Date.now() - 2 * 864e5).toISOString(), gameName: "Fortnite", durationSec: 5 * 3600 },
          liveNow: previewMode === "live" ? {
            startedAt: new Date(Date.now() - 2 * 36e5 - 14 * 6e4).toISOString(),
            gameName: "Fortnite",
            title: "ranked grind to masters w/ friends"
          } : null,
          generatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        setState({ kind: "ok", data: mock, fmt });
      }
      return () => {
        cancelled = true;
      };
    }
    async function load(auth, fmt, cfg) {
      try {
        const data = await fetchPanel(auth.channelId, auth.token, cfg.tz);
        if (cancelled) return;
        if (data.status === "ok") setState({ kind: "ok", data, fmt });
        else if (data.status === "warming") {
          setState({ kind: "warming", fmt });
          timer = setTimeout(() => load(auth, fmt, cfg), WARMING_RETRY_MS);
        } else setState({ kind: "no_data", fmt });
      } catch (err) {
        if (!cancelled) {
          setState({ kind: "error", message: err instanceof Error ? err.message : "unknown" });
        }
      }
    }
    Promise.all([awaitAuthorized(), awaitConfiguration()]).then(async ([auth, rawCfg]) => {
      const cfg = parseConfig(rawCfg);
      document.documentElement.style.setProperty("--accent", cfg.accentColor);
      document.documentElement.style.setProperty("--accent-text", pickTextColor(cfg.accentColor));
      setConfig(cfg);
      const fmt = {
        locale: resolveViewerLocale(),
        timeZone: resolveViewerTimeZone()
      };
      return load(auth, fmt, cfg);
    }).catch(
      (err) => setState({ kind: "error", message: err instanceof Error ? err.message : "unknown" })
    );
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, []);
  if (state.kind === "loading") return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "loading", children: "Loading…" });
  if (state.kind === "warming") return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "loading", children: "Analyzing recent broadcasts…" });
  if (state.kind === "error") return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "error", children: "Unable to load panel." });
  if (state.kind === "no_data")
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(NoDataSkeleton, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(PoweredByFooter, { campaign: "panel_empty" })
    ] });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    state.data.liveNow ? /* @__PURE__ */ jsxRuntimeExports.jsx(LiveNowHero, { liveNow: state.data.liveNow }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ScheduleSummary, { summary: state.data.summary }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Heatmap, { perDay: state.data.summary.perDay, tz: state.data.summary.tz }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PoweredByFooter, { campaign: "panel_footer", generatedAt: state.data.generatedAt })
  ] });
}
const root = document.getElementById("root");
if (root) {
  clientExports.createRoot(root).render(
    /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Panel, {}) })
  );
}
