import { r as reactExports, p as parseConfig, j as jsxRuntimeExports, d as setBroadcasterConfiguration, s as serializeConfig, c as clientExports, a as awaitAuthorized, b as awaitConfiguration, f as fetchPanel } from "./configSchema-CPGIH2Sn.js";
const CONFIG_VERSION = "1";
const API_BASE = "https://collab.deutschmark.online";
const COMMON_TIMEZONES = [
  { tz: "Pacific/Honolulu", name: "Hawaii (HST)" },
  { tz: "America/Anchorage", name: "Alaska (AKT)" },
  { tz: "America/Los_Angeles", name: "Pacific (PT)" },
  { tz: "America/Phoenix", name: "Arizona (MST, no DST)" },
  { tz: "America/Denver", name: "Mountain (MT)" },
  { tz: "America/Chicago", name: "Central (CT)" },
  { tz: "America/New_York", name: "Eastern (ET)" },
  { tz: "America/Halifax", name: "Atlantic (AT)" },
  { tz: "America/Sao_Paulo", name: "Brazil (BRT)" },
  { tz: "UTC", name: "UTC" },
  { tz: "Europe/London", name: "London (GMT/BST)" },
  { tz: "Europe/Paris", name: "Central Europe (CET) — Paris" },
  { tz: "Europe/Berlin", name: "Central Europe (CET) — Berlin" },
  { tz: "Europe/Athens", name: "Eastern Europe (EET)" },
  { tz: "Europe/Moscow", name: "Moscow (MSK)" },
  { tz: "Asia/Dubai", name: "Dubai (GST)" },
  { tz: "Asia/Kolkata", name: "India (IST)" },
  { tz: "Asia/Singapore", name: "Singapore (SGT)" },
  { tz: "Asia/Tokyo", name: "Japan (JST)" },
  { tz: "Asia/Seoul", name: "Korea (KST)" },
  { tz: "Australia/Perth", name: "Perth (AWST)" },
  { tz: "Australia/Sydney", name: "Sydney (AET)" },
  { tz: "Pacific/Auckland", name: "Auckland (NZT)" }
];
function utcOffset(tz) {
  try {
    const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "shortOffset" });
    const parts = fmt.formatToParts(/* @__PURE__ */ new Date());
    const raw = parts.find((p) => p.type === "timeZoneName")?.value ?? "";
    return raw.replace("GMT", "UTC").replace("-", "−");
  } catch {
    return "";
  }
}
function SettingsForm({ initialRaw, channelId, token }) {
  const initial = reactExports.useMemo(() => {
    const parsed = parseConfig(initialRaw);
    if (!initialRaw) {
      const detected = Intl.DateTimeFormat().resolvedOptions().timeZone;
      return { ...parsed, tz: detected };
    }
    return parsed;
  }, [initialRaw]);
  const [tz, setTz] = reactExports.useState(initial.tz);
  const [showGame, setShowGame] = reactExports.useState(initial.showGame);
  const [accentColor, setAccentColor] = reactExports.useState(initial.accentColor);
  const [hexInput, setHexInput] = reactExports.useState(initial.accentColor);
  const [hexCopied, setHexCopied] = reactExports.useState(false);
  const [status, setStatus] = reactExports.useState("idle");
  const [colorFetchStatus, setColorFetchStatus] = reactExports.useState("idle");
  reactExports.useEffect(() => setHexInput(accentColor), [accentColor]);
  function commitHex(value) {
    let v = value.trim().toUpperCase();
    if (v && !v.startsWith("#")) v = "#" + v;
    if (/^#[0-9A-F]{6}$/.test(v)) {
      setAccentColor(v);
    } else {
      setHexInput(accentColor);
    }
  }
  async function copyHex() {
    try {
      await navigator.clipboard.writeText(accentColor);
      setHexCopied(true);
      setTimeout(() => setHexCopied(false), 1500);
    } catch {
    }
  }
  const tzOptions = reactExports.useMemo(() => {
    const supported = Intl.supportedValuesOf;
    return supported ? supported("timeZone") : [];
  }, []);
  async function fetchTwitchColor() {
    setColorFetchStatus("loading");
    try {
      const res = await fetch(
        `${API_BASE}/api/extension/channel/${channelId}/twitch-color`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const body = await res.json();
      if (body.color) {
        setAccentColor(body.color);
        setColorFetchStatus("idle");
      } else {
        setColorFetchStatus("none");
      }
    } catch {
      setColorFetchStatus("none");
    }
  }
  function buildConfig() {
    return {
      v: 1,
      tz,
      showGame,
      accentColor
    };
  }
  function save(e) {
    e.preventDefault();
    setStatus("saving");
    try {
      const cfg = buildConfig();
      setBroadcasterConfiguration(CONFIG_VERSION, serializeConfig(cfg));
      setStatus("saved");
      setTimeout(() => setStatus("idle"), 2e3);
    } catch {
      setStatus("error");
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { className: "settings-form", onSubmit: save, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Timezone" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "select",
        {
          value: tz,
          onChange: (e) => setTz(e.target.value),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("optgroup", { label: "Common", children: COMMON_TIMEZONES.map(({ tz: z, name }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: z, children: [
              name,
              " · ",
              utcOffset(z)
            ] }, z)) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("optgroup", { label: "All zones", children: [
              !tzOptions.includes(tz) && !COMMON_TIMEZONES.find((c) => c.tz === tz) && /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: tz, children: [
                tz,
                " · ",
                utcOffset(tz)
              ] }),
              tzOptions.map((z) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: z, children: [
                z,
                " · ",
                utcOffset(z)
              ] }, z))
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("small", { children: "Separate from your Collab Planner timezone." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "checkbox", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: showGame, onChange: (e) => setShowGame(e.target.checked) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Show top game" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "span",
        {
          className: "info-tip",
          "data-tip": "Shows your most-played recent game as a small chip below the schedule. Variety streamers may want this off.",
          "aria-label": "What does this do?",
          children: "ⓘ"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Accent color" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "accent-block", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "color",
            className: "accent-swatch",
            value: accentColor,
            onChange: (e) => setAccentColor(e.target.value.toUpperCase()),
            "aria-label": "Open color picker"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            className: "accent-hex",
            value: hexInput,
            onChange: (e) => setHexInput(e.target.value),
            onBlur: (e) => commitHex(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                commitHex(hexInput);
              }
            },
            maxLength: 7,
            spellCheck: false,
            "aria-label": "Hex color value"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            className: "accent-copy",
            onClick: copyHex,
            "aria-label": "Copy hex value",
            children: hexCopied ? "Copied" : "Copy"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "accent-actions", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", className: "accent-twitch-btn", onClick: fetchTwitchColor, children: colorFetchStatus === "loading" ? "Fetching…" : "Use my Twitch profile color" }),
        colorFetchStatus === "none" && /* @__PURE__ */ jsxRuntimeExports.jsx("small", { children: "No profile color set on Twitch." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", className: "cta", disabled: status === "saving", children: status === "saving" ? "Saving…" : "Save" }),
    status === "saved" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "saved-toast", children: "Saved ✓" }),
    status === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "form-error", children: "Couldn't save — try again." })
  ] });
}
const DASHBOARD = "https://collab.deutschmark.online";
const SIGN_IN = `${DASHBOARD}/?utm_source=twitch_ext&utm_medium=config_view&utm_campaign=not_in_cp`;
const OPEN_DASH = `${DASHBOARD}/?utm_source=twitch_ext&utm_medium=config_view&utm_campaign=connected`;
function StatusStrip({ state }) {
  if (state.kind === "loading") return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "loading", children: "Loading…" });
  if (state.kind === "error") return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "error", children: "Unable to load config." });
  if (state.kind === "not_in_cp") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "Panel is live ✓" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Predictions are auto-built from this channel's recent broadcasts — no signup needed." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "upgrade-note", children: "Sign in at Collab Planner to add planned collabs and sharper predictions." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { className: "cta-secondary", href: SIGN_IN, target: "_blank", rel: "noopener noreferrer", children: "Sign in (optional) ↗" }) })
    ] });
  }
  if (state.kind === "no_data") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "Collab Planner ✓" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Account detected. Predictions will populate as your broadcast history syncs." })
    ] });
  }
  if (state.kind === "warming") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "Collab Planner ✓" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Account detected. Analyzing your recent broadcasts — panel will populate within a few minutes." })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { children: "Collab Planner ✓" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
      "Account detected. Streams ",
      state.topDays.join(", ") || "various days",
      ",",
      " ",
      state.collabs,
      " upcoming collab",
      state.collabs === 1 ? "" : "s",
      "."
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("a", { className: "cta", href: OPEN_DASH, target: "_blank", rel: "noopener noreferrer", children: "Open dashboard ↗" }) })
  ] });
}
function Config() {
  const [state, setState] = reactExports.useState({ kind: "loading" });
  const [authState, setAuthState] = reactExports.useState(null);
  const [configRaw, setConfigRaw] = reactExports.useState(null);
  reactExports.useEffect(() => {
    const previewMode = new URLSearchParams(window.location.search).get("preview");
    if (previewMode) {
      setAuthState({ channelId: "12345", clientId: "preview", token: "preview", userId: "u1" });
      setConfigRaw(null);
    }
    if (previewMode === "connected") {
      setState({ kind: "connected", topDays: ["Sun", "Tue", "Mon"], collabs: 2 });
      return;
    }
    if (previewMode === "warming") {
      setState({ kind: "warming" });
      return;
    }
    if (previewMode === "not_in_cp" || previewMode === "no_data") {
      setState({ kind: previewMode });
      return;
    }
    Promise.all([awaitAuthorized(), awaitConfiguration()]).then(async ([auth, rawCfg]) => {
      setAuthState(auth);
      setConfigRaw(rawCfg);
      try {
        const data = await fetchPanel(auth.channelId, auth.token, "UTC");
        if (data.status === "ok") {
          setState({
            kind: "connected",
            topDays: data.summary.topDays,
            collabs: data.collabs.length
          });
        } else if (data.status === "warming") {
          setState({ kind: "warming" });
        } else {
          setState({ kind: "no_data" });
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : "unknown";
        if (msg.includes("404")) setState({ kind: "not_in_cp" });
        else setState({ kind: "error", message: msg });
      }
    }).catch(
      (err) => setState({ kind: "error", message: err instanceof Error ? err.message : "unknown" })
    );
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(StatusStrip, { state }),
    authState && /* @__PURE__ */ jsxRuntimeExports.jsx(
      SettingsForm,
      {
        initialRaw: configRaw,
        channelId: authState.channelId,
        token: authState.token
      }
    )
  ] });
}
const root = document.getElementById("root");
if (root) {
  clientExports.createRoot(root).render(
    /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Config, {}) })
  );
}
