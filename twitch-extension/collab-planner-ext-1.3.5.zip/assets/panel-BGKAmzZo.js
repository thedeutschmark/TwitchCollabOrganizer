import { r as reactExports, j as jsxRuntimeExports, c as clientExports, D as DEFAULT_CONFIG, a as awaitAuthorized, b as awaitConfiguration, p as parseConfig, f as fetchPanel } from "./configSchema-BGbsG3Hz.js";
function formatHour(hour, use24, minute = 0) {
  const hr = (hour % 24 + 24) % 24;
  const mm = minute === 30 ? "30" : "00";
  if (use24) return `${hr.toString().padStart(2, "0")}:${mm}`;
  const h12 = hr % 12 || 12;
  const ampm = hr >= 12 ? "PM" : "AM";
  if (minute === 0) return `${h12} ${ampm}`;
  return `${h12}:${mm} ${ampm}`;
}
function formatHourCompact(hour, use24) {
  const hr = (hour % 24 + 24) % 24;
  if (use24) return hr.toString();
  const h12 = hr % 12 || 12;
  return `${h12}${hr >= 12 ? "pm" : "am"}`;
}
function resolveViewerTimeZone() {
  return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
}
function resolveViewerLocale(twitchLocale) {
  if (typeof navigator !== "undefined" && navigator.language) return navigator.language;
  return "en-US";
}
function pickTextColor(hex) {
  const m = /^#([0-9a-fA-F]{6})$/.exec(hex);
  if (!m) return "#FFFFFF";
  const n = parseInt(m[1], 16);
  const r = n >> 16 & 255;
  const g = n >> 8 & 255;
  const b = n & 255;
  const channel = (c) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  };
  const L = 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
  return L > 0.179 ? "#000000" : "#FFFFFF";
}
const subscribers = /* @__PURE__ */ new Set();
let timeoutId = null;
function scheduleNextTick() {
  const msUntilNextMinute = 6e4 - Date.now() % 6e4;
  timeoutId = setTimeout(() => {
    const now = Date.now();
    for (const fn of subscribers) fn(now);
    if (subscribers.size > 0) scheduleNextTick();
    else timeoutId = null;
  }, msUntilNextMinute);
}
function subscribe(fn) {
  subscribers.add(fn);
  if (timeoutId === null) scheduleNextTick();
  return () => {
    subscribers.delete(fn);
    if (subscribers.size === 0 && timeoutId !== null) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
  };
}
function useMinuteTick() {
  const [nowMs, setNowMs] = reactExports.useState(() => Date.now());
  reactExports.useEffect(() => subscribe(setNowMs), []);
  return nowMs;
}
const DAY_NAMES_FULL = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const DAY_NAMES_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const TODAY_GRACE_HOURS = 3;
function nextLikelyLiveDate(topDays, medianHour) {
  if (topDays.length === 0) return null;
  const activeDows = topDays.map((d) => DAY_NAMES_SHORT.indexOf(d)).filter((i) => i !== -1);
  if (activeDows.length === 0) return null;
  const now = /* @__PURE__ */ new Date();
  const graceMs = TODAY_GRACE_HOURS * 36e5;
  for (let i = 0; i < 14; i++) {
    const candidate = new Date(now);
    candidate.setDate(candidate.getDate() + i);
    candidate.setHours(medianHour, 0, 0, 0);
    if (candidate.getTime() <= now.getTime() - graceMs) continue;
    if (activeDows.includes(candidate.getDay())) return candidate;
  }
  return null;
}
function formatCountdown(target, nowMs) {
  if (!target) return "";
  const diffMs = target.getTime() - nowMs;
  if (diffMs <= 0) return "any minute";
  const totalMin = Math.floor(diffMs / 6e4);
  const days = Math.floor(totalMin / (24 * 60));
  const hours = Math.floor(totalMin % (24 * 60) / 60);
  const mins = totalMin % 60;
  const word = (n, singular) => `${n} ${n === 1 ? singular : `${singular}s`}`;
  const parts = [];
  if (days > 0) parts.push(word(days, "day"));
  if (hours > 0) parts.push(word(hours, "hour"));
  if (mins > 0 && days === 0) parts.push(word(mins, "minute"));
  if (parts.length === 0) return "any minute";
  if (parts.length === 1) return parts[0];
  return `${parts[0]} and ${parts[1]}`;
}
function nextLikelyRelative(topDays, medianHour) {
  if (topDays.length === 0) return null;
  const activeDows = topDays.map((d) => DAY_NAMES_SHORT.indexOf(d)).filter((i) => i !== -1);
  if (activeDows.length === 0) return null;
  const now = /* @__PURE__ */ new Date();
  const todayDow = now.getDay();
  const currentHour = now.getHours();
  for (let i = 0; i < 7; i++) {
    const checkDow = (todayDow + i) % 7;
    if (!activeDows.includes(checkDow)) continue;
    if (i === 0 && currentHour >= medianHour + TODAY_GRACE_HOURS) continue;
    const dayLabel = DAY_NAMES_SHORT[checkDow];
    const fullDay = DAY_NAMES_FULL[checkDow];
    let relative;
    if (i === 0) {
      const hoursAway = medianHour - currentHour;
      if (hoursAway <= 0) relative = "any minute";
      else if (hoursAway <= 2) relative = "soon";
      else if (hoursAway <= 6) relative = `in ${hoursAway}h`;
      else relative = "tonight";
    } else if (i === 1) relative = "tomorrow";
    else relative = `in ${i} days`;
    return { dayLabel, fullDay, relative };
  }
  return null;
}
function buildVariant(args) {
  const { medianHour, medianMinute, avgDurationHours, next, countdown, hoursUntilNext, broadcasterName, use24Hour } = args;
  const start = formatHour(medianHour, use24Hour, medianMinute);
  const end = formatHour(medianHour + Math.max(1, Math.round(avgDurationHours)), use24Hour, medianMinute);
  const name = broadcasterName ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "broadcaster-name", children: broadcasterName }) : null;
  const goesLive = name ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    name,
    " goes live"
  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: "Next stream" });
  if (!next) {
    return {
      eyebrow: name ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        name,
        " - no pattern yet"
      ] }) : "Next stream",
      hero: "—",
      heroTone: "dim",
      support: "Not enough broadcast history to predict yet."
    };
  }
  if (next.relative === "any minute") {
    return {
      eyebrow: name ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        name,
        " is usually live"
      ] }) : "Usually live",
      hero: "Right now",
      support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("strong", { children: [
          start,
          " to ",
          end
        ] }),
        "."
      ] })
    };
  }
  const isCountdownActive = hoursUntilNext !== null && hoursUntilNext < 12 && hoursUntilNext >= 0;
  if (isCountdownActive) {
    return {
      eyebrow: name ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        name,
        " goes live in"
      ] }) : "Next stream in",
      hero: countdown || next.relative,
      support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "around ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: start }),
        "."
      ] })
    };
  }
  if (next.relative === "tomorrow") {
    return {
      eyebrow: goesLive,
      hero: "Tomorrow",
      support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "around ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: start }),
        "."
      ] })
    };
  }
  return {
    eyebrow: goesLive,
    hero: next.fullDay,
    support: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "around ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: start }),
      "."
    ] })
  };
}
function ScheduleSummary({ summary, use24Hour = false }) {
  const { topDays, medianHour, avgDurationHours, isEstimate } = summary;
  const next = nextLikelyRelative(topDays, medianHour);
  const nextDate = nextLikelyLiveDate(topDays, medianHour);
  const nowMs = useMinuteTick();
  const countdown = formatCountdown(nextDate, nowMs);
  const hoursUntilNext = nextDate ? (nextDate.getTime() - nowMs) / 36e5 : null;
  const v = buildVariant({
    medianHour,
    medianMinute: summary.medianMinute ?? 0,
    avgDurationHours,
    next,
    countdown,
    hoursUntilNext,
    broadcasterName: summary.broadcasterName,
    use24Hour
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule-eyebrow", children: [
      v.eyebrow,
      isEstimate && " (est.)"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `schedule-hero schedule-hero-${v.heroTone ?? "accent"}`, children: v.hero }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-support", children: v.support }),
    v.secondary && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-secondary", children: v.secondary })
  ] });
}
function formatClock(ms, tz, use24Hour) {
  return new Date(ms).toLocaleTimeString("en-US", {
    hour: use24Hour ? "2-digit" : "numeric",
    minute: "2-digit",
    timeZone: tz,
    hour12: !use24Hour
  });
}
function getTzShort(tz) {
  try {
    const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, timeZoneName: "short" });
    const raw = fmt.formatToParts(/* @__PURE__ */ new Date()).find((p) => p.type === "timeZoneName")?.value ?? tz;
    const us = raw.match(/^(E|C|M|P|A|H)(D|S)T$/);
    if (us) return `${us[1]}ST`;
    if (/^AK[DS]T$/.test(raw)) return "AKST";
    return raw;
  } catch {
    return tz;
  }
}
function PoweredByFooter({ campaign, generatedAt, hasPostedSchedule, tz, use24Hour }) {
  const href = `https://collab.deutschmark.online/?utm_source=twitch_ext&utm_medium=panel&utm_campaign=${campaign}`;
  const nowMs = useMinuteTick();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "powered-by", children: [
    generatedAt && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "powered-by-tick", title: `Data refreshed ${formatClock(new Date(generatedAt).getTime(), tz, use24Hour)}`, children: [
      hasPostedSchedule && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "powered-by-posted-dot", "aria-hidden": "true", title: "Broadcaster has a posted Twitch schedule" }),
      "as of ",
      formatClock(nowMs, tz, use24Hour),
      tz && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        " ",
        getTzShort(tz)
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href, target: "_blank", rel: "noopener noreferrer", children: [
      "Powered by Collab Planner ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { "aria-hidden": "true", children: "↗" })
    ] })
  ] });
}
const MIN_SPAN_HOURS = 10;
const PAD_BEFORE = 2;
const PAD_AFTER = 1;
function computeAxisRange(perDay) {
  const high = perDay.filter((d) => d.confidence === "high");
  if (high.length === 0) {
    return { startHour: 12, endHour: 24 };
  }
  const earliestStart = Math.min(...high.map((d) => d.startHour));
  const latestEnd = Math.max(...high.map((d) => d.startHour + d.durationHours));
  let startHour = earliestStart - PAD_BEFORE;
  const endHour = latestEnd + PAD_AFTER;
  if (endHour <= 24 && endHour - startHour < MIN_SPAN_HOURS) {
    startHour = Math.max(0, endHour - MIN_SPAN_HOURS);
  }
  return { startHour, endHour };
}
const DAY_LETTERS_SUN = ["Sun", "Mon", "Tue", "Wed", "Th", "Fri", "Sat"];
const DAY_LETTERS_MON = ["Mon", "Tue", "Wed", "Th", "Fri", "Sat", "Sun"];
const DAY_ORDER_SUN = [0, 1, 2, 3, 4, 5, 6];
const DAY_ORDER_MON = [1, 2, 3, 4, 5, 6, 0];
const DOW_BY_SHORT = {
  Sun: 0,
  Mon: 1,
  Tue: 2,
  Wed: 3,
  Thu: 4,
  Fri: 5,
  Sat: 6
};
const hourFmtCache = /* @__PURE__ */ new Map();
const dowFmtCache = /* @__PURE__ */ new Map();
function getHourFmt(tz) {
  let f = hourFmtCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: false });
    hourFmtCache.set(tz, f);
  }
  return f;
}
function getDowFmt(tz) {
  let f = dowFmtCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" });
    dowFmtCache.set(tz, f);
  }
  return f;
}
function nowHourInTz$1(tz, nowMs) {
  const parts = getHourFmt(tz).formatToParts(new Date(nowMs));
  const h = parseInt(parts.find((p) => p.type === "hour")?.value ?? "0", 10);
  const m = parseInt(parts.find((p) => p.type === "minute")?.value ?? "0", 10);
  return (h === 24 ? 0 : h) + m / 60;
}
function nowDowInTz$1(tz, nowMs) {
  const w = getDowFmt(tz).formatToParts(new Date(nowMs)).find((p) => p.type === "weekday")?.value ?? "Sun";
  return DOW_BY_SHORT[w] ?? 0;
}
function Heatmap({ perDay, tz, sampleSize, hasPostedSchedule, use24Hour = false, weekStartsMonday = false }) {
  const fmtHour = (h) => formatHourCompact(h, use24Hour);
  const nowMs = useMinuteTick();
  const dayLetters = weekStartsMonday ? DAY_LETTERS_MON : DAY_LETTERS_SUN;
  const dayOrder = weekStartsMonday ? DAY_ORDER_MON : DAY_ORDER_SUN;
  const byDow = reactExports.useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    if (perDay) for (const e of perDay) m.set(e.dow, e);
    return m;
  }, [perDay]);
  if (!perDay || perDay.length === 0) return null;
  const { startHour, endHour } = computeAxisRange(perDay);
  const spanH = endHour - startHour;
  const todayDow = nowDowInTz$1(tz, nowMs);
  const nowH = nowHourInTz$1(tz, nowMs);
  const nowInRange = nowH >= startHour && nowH < endHour;
  const nowPct = nowInRange ? (nowH - startHour) / spanH * 100 : -1;
  const ticks = [];
  for (let h = Math.ceil(startHour / 2) * 2; h < endHour; h += 2) {
    ticks.push({ hour: h, pct: (h - startHour) / spanH * 100 });
  }
  const wrapperStyle = { "--now-pct": nowPct };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal", style: wrapperStyle, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-rows", children: dayOrder.map((dow, idx) => {
      const letter = dayLetters[idx];
      const entry = byDow.get(dow);
      const isToday = dow === todayDow;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `weekcal-row ${isToday ? "weekcal-row-today" : ""}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `weekcal-day ${isToday ? "weekcal-day-today" : entry ? "weekcal-day-active" : "weekcal-day-empty"}`, children: letter }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-strip", children: [
          ticks.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: "weekcal-gridline",
              style: { left: `${t.pct}%` }
            },
            t.hour
          )),
          isToday && nowInRange && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-now-line", style: { left: `${nowPct}%` } }),
          entry && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `weekcal-pill weekcal-pill-${entry.confidence}`,
              style: {
                left: `${(entry.startHour - startHour) / spanH * 100}%`,
                width: `${entry.durationHours / spanH * 100}%`
              },
              title: `${fmtHour(entry.startHour)}–${fmtHour(entry.startHour + entry.durationHours)}${entry.confidence === "low" ? " (projected — low confidence)" : " (projected)"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-pill-label", children: fmtHour(entry.startHour) })
            }
          )
        ] })
      ] }, dow);
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-axis", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-axis-corner" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-axis-track", children: ticks.map((t) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-axis-tick", style: { left: `${t.pct}%` }, children: fmtHour(t.hour) }, t.hour)) })
    ] }),
    (sampleSize ?? 0) > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "weekcal-thin-bar",
        title: `Auto-built from ${sampleSize} ${sampleSize === 1 ? "VOD" : "VODs"}${hasPostedSchedule ? " + posted schedule" : ""}`
      }
    )
  ] });
}
function formatElapsed(startedAtMs, nowMs) {
  const diff = Math.max(0, nowMs - startedAtMs);
  const totalMin = Math.floor(diff / 6e4);
  const hours = Math.floor(totalMin / 60);
  const mins = totalMin % 60;
  if (hours > 0) return `${hours}h ${mins}m`;
  return `${mins}m`;
}
function nowDowInTz(tz) {
  const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" });
  const w = fmt.formatToParts(/* @__PURE__ */ new Date()).find((p) => p.type === "weekday")?.value ?? "Sun";
  return { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[w] ?? 0;
}
function nowHourInTz(tz) {
  const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "2-digit", hour12: false });
  const h = parseInt(fmt.formatToParts(/* @__PURE__ */ new Date()).find((p) => p.type === "hour")?.value ?? "0", 10);
  return h === 24 ? 0 : h;
}
function classify(summary) {
  const { perDay, tz } = summary;
  if (!perDay || perDay.length === 0) return { kind: "unknown" };
  const dow = nowDowInTz(tz);
  const hour = nowHourInTz(tz);
  const entry = perDay.find((d) => d.dow === dow);
  if (!entry) return { kind: "off_day" };
  const start = entry.startHour;
  const end = entry.startHour + entry.durationHours;
  if (hour >= start - 0.5 && hour < end + 0.5) return { kind: "on_time" };
  if (hour < start) return { kind: "early", usualHour: start };
  return { kind: "late", usualHour: start };
}
const OFF_DAY_PHRASES = [
  "What a treat",
  "Surprise stream",
  "Unexpected drop",
  "Bonus stream tonight",
  "Off-script tonight"
];
const EARLY_PHRASES = [
  "Going live early",
  "Ahead of schedule",
  "Jumped on early",
  "Early start tonight",
  "Beating the clock"
];
const LATE_PHRASES = [
  "Running late",
  "Late start tonight",
  "Just got going",
  "Catching up",
  "Off to a slow start"
];
const ON_TIME_VERBS = [
  "Streaming",
  "Playing",
  "Live with",
  "Tonight:",
  "Now playing"
];
function pickFromSeed(arr, seed) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = h * 31 + seed.charCodeAt(i) | 0;
  return arr[Math.abs(h) % arr.length];
}
function buildCopy(ctx, liveNow, name, use24Hour) {
  const who = name ?? "this streamer";
  const game = liveNow.gameName;
  const seed = liveNow.startedAt;
  switch (ctx.kind) {
    case "off_day": {
      const phrase = pickFromSeed(OFF_DAY_PHRASES, seed);
      return {
        eyebrow: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          who,
          " is ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "not usually live today" })
        ] }),
        support: game ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          phrase,
          " — ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: game }),
          "."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          phrase,
          "."
        ] })
      };
    }
    case "early": {
      const phrase = pickFromSeed(EARLY_PHRASES, seed);
      return {
        eyebrow: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          who,
          " is on ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "early today" })
        ] }),
        support: game ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          phrase,
          " — ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: game }),
          "."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          phrase,
          " — usually around ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: formatHour(ctx.usualHour, use24Hour) }),
          "."
        ] })
      };
    }
    case "late": {
      const phrase = pickFromSeed(LATE_PHRASES, seed);
      return {
        eyebrow: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          who,
          " is ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "running late" })
        ] }),
        support: game ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          phrase,
          " — ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: game }),
          "."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          phrase,
          " — usually around ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: formatHour(ctx.usualHour, use24Hour) }),
          "."
        ] })
      };
    }
    case "on_time": {
      const verb = pickFromSeed(ON_TIME_VERBS, seed);
      return {
        eyebrow: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          who,
          " is live ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "right on time" })
        ] }),
        support: game ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          verb,
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: game }),
          "."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: "Live now." })
      };
    }
    case "unknown":
    default:
      return {
        eyebrow: "Live now",
        support: game ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Streaming ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: game }),
          "."
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: "Live right now." })
      };
  }
}
function LiveNowHero({ liveNow, summary, use24Hour = false }) {
  const startedAtMs = new Date(liveNow.startedAt).getTime();
  const nowMs = useMinuteTick();
  const elapsed = formatElapsed(startedAtMs, nowMs);
  const ctx = classify(summary);
  const copy = buildCopy(ctx, liveNow, summary.broadcasterName, use24Hour);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule live-hero", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule-eyebrow live-eyebrow", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "live-dot", "aria-hidden": true }),
      copy.eyebrow
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-hero schedule-hero-live", children: elapsed }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-support", children: copy.support })
  ] });
}
const MESSAGES = [
  "scanning VOD history",
  "binning by day of week",
  "computing median start time",
  "inferring typical duration",
  "cross-checking posted schedule",
  "compiling weekly forecast",
  "smoothing recency curve"
];
function LoadingHero({ interval = 1500 }) {
  const [idx, setIdx] = reactExports.useState(0);
  reactExports.useEffect(() => {
    const id = setInterval(() => setIdx((i) => (i + 1) % MESSAGES.length), interval);
    return () => clearInterval(id);
  }, [interval]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "loading-hero", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "loading-spinner", "aria-hidden": true }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "loading-text", "aria-live": "polite", children: [
      MESSAGES[idx],
      "…"
    ] }, idx)
  ] });
}
const DAY_LETTERS = ["Sun", "Mon", "Tue", "Wed", "Th", "Fri", "Sat"];
function NoDataSkeleton() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "schedule", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-eyebrow", children: "Forecast warming up" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-hero schedule-hero-dim", children: "—" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-support", children: "Crunching broadcast history. Try refreshing in a minute." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "schedule-secondary", children: "Predictions appear automatically once there are 3+ recent streams to learn from." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal skeleton", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-rows", children: DAY_LETTERS.map((letter, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "weekcal-row", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "weekcal-day weekcal-day-empty", children: letter }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "weekcal-strip" })
    ] }, i)) }) })
  ] });
}
const WARMING_RETRY_MS = 5e3;
function Panel() {
  const [state, setState] = reactExports.useState({ kind: "loading" });
  const [config, setConfig] = reactExports.useState(DEFAULT_CONFIG);
  reactExports.useEffect(() => {
    let cancelled = false;
    let timer = null;
    const previewMode = new URLSearchParams(window.location.search).get("preview");
    if (previewMode) {
      const fmt = {
        locale: resolveViewerLocale(),
        timeZone: resolveViewerTimeZone()
      };
      if (previewMode === "warming") {
        setState({ kind: "warming", fmt });
      } else if (previewMode === "no_data") {
        setState({ kind: "no_data", fmt });
      } else {
        const mock = {
          status: "ok",
          summary: {
            topDays: ["Mon", "Wed", "Sat"],
            medianHour: 19,
            // 7 PM local
            tz: "America/New_York",
            topGame: "Fortnite",
            topGames: ["Fortnite", "Just Chatting", "League of Legends"],
            isEstimate: false,
            hasPostedSchedule: true,
            // Spread evening hours: ramps up 6-8 PM, peaks 8-10, tails to midnight.
            hourDistribution: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4, 0.9, 1, 0.9, 0.6, 0.3],
            // Mon + Wed + Sat are the regulars; everything else background noise.
            dayFrequency: [0.2, 1, 0.2, 0.9, 0.3, 0.2, 0.8],
            avgDurationHours: 5,
            perDay: [
              { dow: 1, startHour: 19, durationHours: 5, confidence: "high" },
              { dow: 3, startHour: 19, durationHours: 5, confidence: "high" },
              { dow: 6, startHour: 18, durationHours: 5, confidence: "high" }
            ],
            sampleSize: 30,
            medianMinute: 30,
            broadcasterAvatar: "https://static-cdn.jtvnw.net/jtv_user_pictures/54c170ef-e1d0-463d-adda-922e751ef6b8-profile_image-300x300.png",
            broadcasterName: "thedeutschmark"
          },
          lastStream: { startedAt: new Date(Date.now() - 2 * 864e5).toISOString(), gameName: "Fortnite", durationSec: 5 * 3600 },
          liveNow: previewMode === "live" ? {
            startedAt: new Date(Date.now() - 2 * 36e5 - 14 * 6e4).toISOString(),
            gameName: "Fortnite",
            title: "ranked grind to masters w/ friends"
          } : null,
          generatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        setState({ kind: "ok", data: mock, fmt });
      }
      return () => {
        cancelled = true;
      };
    }
    async function load(auth, fmt, cfg) {
      try {
        const data = await fetchPanel(auth.channelId, auth.token, cfg.tz);
        if (cancelled) return;
        if (data.status === "ok") setState({ kind: "ok", data, fmt });
        else if (data.status === "warming") {
          setState({ kind: "warming", fmt });
          timer = setTimeout(() => load(auth, fmt, cfg), WARMING_RETRY_MS);
        } else setState({ kind: "no_data", fmt });
      } catch (err) {
        if (!cancelled) {
          setState({ kind: "error", message: err instanceof Error ? err.message : "unknown" });
        }
      }
    }
    Promise.all([awaitAuthorized(), awaitConfiguration()]).then(async ([auth, rawCfg]) => {
      const cfg = parseConfig(rawCfg);
      document.documentElement.style.setProperty("--accent", cfg.accentColor);
      document.documentElement.style.setProperty("--accent-text", pickTextColor(cfg.accentColor));
      setConfig(cfg);
      const fmt = {
        locale: resolveViewerLocale(),
        timeZone: resolveViewerTimeZone()
      };
      return load(auth, fmt, cfg);
    }).catch(
      (err) => setState({ kind: "error", message: err instanceof Error ? err.message : "unknown" })
    );
    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, []);
  if (state.kind === "loading") return /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingHero, {});
  if (state.kind === "warming") return /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingHero, {});
  if (state.kind === "error") return /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "error", children: "Unable to load panel." });
  if (state.kind === "no_data")
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(NoDataSkeleton, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(PoweredByFooter, { campaign: "panel_empty" })
    ] });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    state.data.liveNow ? /* @__PURE__ */ jsxRuntimeExports.jsx(LiveNowHero, { liveNow: state.data.liveNow, summary: state.data.summary, use24Hour: config.use24Hour }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ScheduleSummary, { summary: state.data.summary, use24Hour: config.use24Hour }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Heatmap,
      {
        perDay: state.data.summary.perDay,
        tz: state.data.summary.tz,
        sampleSize: state.data.summary.sampleSize,
        hasPostedSchedule: state.data.summary.hasPostedSchedule,
        use24Hour: config.use24Hour,
        weekStartsMonday: config.weekStartsMonday
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PoweredByFooter,
      {
        campaign: "panel_footer",
        generatedAt: state.data.generatedAt,
        hasPostedSchedule: state.data.summary.hasPostedSchedule,
        tz: state.data.summary.tz,
        use24Hour: config.use24Hour
      }
    )
  ] });
}
const root = document.getElementById("root");
if (root) {
  clientExports.createRoot(root).render(
    /* @__PURE__ */ jsxRuntimeExports.jsx(reactExports.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Panel, {}) })
  );
}
